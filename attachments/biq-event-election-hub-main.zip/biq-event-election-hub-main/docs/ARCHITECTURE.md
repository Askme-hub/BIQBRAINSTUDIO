# BIQ Brain Studios — Technical Architecture (Phase 0)

## Routes
| Area | Path | File |
| --- | --- | --- |
| Public | `/`, `/discover`, `/voting`, `/pricing`, `/about`, `/contact`, `/help` | `src/routes/*.tsx` |
| Auth | `/login`, `/register`, `/forgot-password` | `src/routes/*.tsx` (UI only, not wired) |
| User area | `/app` (workspace selector) | `app.index.tsx` |
| Event workspace | `/app/events` (overview), `/app/events/:section` | `app.events.tsx` (layout), `app.events.index.tsx`, `app.events.$section.tsx` |
| Voting workspace | `/app/voting` (Coming Soon) | `app.voting.tsx` |
| Super Admin | `/admin`, `/admin/:section` | `admin.tsx` (layout), `admin.index.tsx`, `admin.$section.tsx` |

Workspace sections are defined once in `src/config/navigation.ts` (slug, icon, copy). Unknown slugs return 404.

## Components
- `brand/Logo` — logo mark + wordmark
- `site/SiteLayout`, `PageHero` — public header (mobile sheet), footer
- `workspace/WorkspaceShell` — collapsible navy sidebar shell shared by Events, Voting and Admin
- `auth/AuthLayout`, `AuthNotice` — split-screen auth layout
- `common/EmptyState`, `PageHeader`, `SectionHeading`

## Design system
Tokens in `src/styles.css` (oklch): `primary` electric blue, `navy`/`navy-soft`, `violet`/`violet-soft`, `success`, `shadow-card`, `shadow-elevated`. Fonts: Sora (display), Plus Jakarta Sans (body).

## Not yet implemented (honest state)
No backend is connected. Auth and contact forms show a notice instead of submitting. KPIs show "—". `/app` and `/admin` are not access-protected yet.

## Next phase — database & security (Phase 1–2)
1. Enable Lovable Cloud (Postgres, Auth, Storage).
2. Identity tables: profiles, organisations, organisation_members, roles (separate table, enum app_role), permissions, role_permissions, invitations, platform_admins.
3. Security-definer `has_role` / `is_org_member(org_id)` helpers; RLS on every table scoped by organisation_id.
4. Wire email/password auth, email verification, `/reset-password` page; move `/app/*` and `/admin/*` under the authenticated route gate; admin gate checks platform_admins server-side; MFA for privileged roles.
5. Event tables (events, ticket_types, registrations, tickets, ticket_scans, budgets, expenses, vendors, sponsors, tasks, schedules…) with UUID PKs, FKs, indexes.
6. Payments: Paystack/Hubtel via server routes under `/api/public/*` with webhook signature verification; secrets stored in Lovable secrets, never in code. Ticket issuance only after verified payment.
7. Voting: voter_credentials/participation kept in tables separate from ballot_submissions/selections; results computed server-side only.
