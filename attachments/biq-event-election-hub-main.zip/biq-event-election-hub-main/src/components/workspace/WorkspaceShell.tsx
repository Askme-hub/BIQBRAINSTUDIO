import { Link } from "@tanstack/react-router";
import { ArrowLeftRight, Bell } from "lucide-react";
import type { ReactNode } from "react";
import { LogoMark } from "@/components/brand/Logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent, SidebarGroupLabel,
  SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuItem, SidebarProvider, SidebarTrigger,
} from "@/components/ui/sidebar";

export function WorkspaceShell({
  name,
  tag,
  groups,
  children,
}: {
  name: string;
  tag: string;
  groups: { label?: string | undefined; items: ReactNode[] }[];
  children: ReactNode;
}) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar collapsible="icon">
          <SidebarHeader className="border-b border-sidebar-border">
            <div className="flex items-center gap-2.5 px-1 py-1.5">
              <LogoMark className="shrink-0" />
              <div className="min-w-0 group-data-[collapsible=icon]:hidden">
                <p className="truncate font-display text-sm font-semibold text-sidebar-accent-foreground">{name}</p>
                <p className="text-xs text-sidebar-foreground/60">{tag}</p>
              </div>
            </div>
          </SidebarHeader>
          <SidebarContent>
            {groups.map((g, i) => (
              <SidebarGroup key={g.label ?? i}>
                {g.label && <SidebarGroupLabel className="text-sidebar-foreground/50">{g.label}</SidebarGroupLabel>}
                <SidebarGroupContent>
                  <SidebarMenu>
                    {g.items.map((item, j) => <SidebarMenuItem key={j}>{item}</SidebarMenuItem>)}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            ))}
          </SidebarContent>
          <SidebarFooter className="border-t border-sidebar-border">
            <Link to="/app" className="flex items-center gap-2 rounded-md px-2 py-2 text-sm text-sidebar-foreground hover:bg-sidebar-accent">
              <ArrowLeftRight className="size-4 shrink-0" />
              <span className="group-data-[collapsible=icon]:hidden">Switch workspace</span>
            </Link>
          </SidebarFooter>
        </Sidebar>
        <SidebarInset>
          <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b bg-background/90 px-4 backdrop-blur">
            <div className="flex items-center gap-3">
              <SidebarTrigger />
              <Badge variant="secondary" className="hidden sm:inline-flex">No organisation selected</Badge>
            </div>
            <Button variant="ghost" size="icon" aria-label="Notifications"><Bell className="size-4" /></Button>
          </header>
          <div className="mx-auto w-full max-w-6xl flex-1 p-4 sm:p-8">{children}</div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
