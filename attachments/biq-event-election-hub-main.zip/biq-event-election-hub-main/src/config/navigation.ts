import {
  LayoutDashboard, CalendarDays, PlusCircle, ClipboardList, Users, Ticket, QrCode, Clock,
  ListChecks, Wallet, Receipt, Store, Handshake, Megaphone, BarChart3, UsersRound, Settings,
  Vote, UserSquare2, BookUser, FileCheck2, Activity, Trophy, ShieldCheck, Building2,
  CreditCard, Banknote, LifeBuoy, Lock, type LucideIcon,
} from "lucide-react";

export type WorkspaceSection = {
  slug: string;
  title: string;
  icon: LucideIcon;
  description: string;
  emptyTitle: string;
  emptyDescription: string;
  group?: string;
};

export const eventSections: WorkspaceSection[] = [
  { slug: "my-events", title: "My Events", icon: CalendarDays, group: "Events", description: "All events owned by this organisation.", emptyTitle: "No events yet", emptyDescription: "Events you create will appear here with their status, dates and registration counts." },
  { slug: "create", title: "Create Event", icon: PlusCircle, group: "Events", description: "Set up a new event with details, venue and ticketing.", emptyTitle: "Event builder arrives in Phase 3", emptyDescription: "You'll set the title, date, venue, cover image and ticket types here once event storage is live." },
  { slug: "registrations", title: "Registrations", icon: ClipboardList, group: "Events", description: "Review and manage registration submissions.", emptyTitle: "No registrations", emptyDescription: "When people register for your events, their submissions and answers will be listed here." },
  { slug: "attendees", title: "Attendees", icon: Users, group: "Events", description: "Everyone confirmed to attend your events.", emptyTitle: "No attendees yet", emptyDescription: "Confirmed attendees will appear here, searchable by name, phone number or ticket." },
  { slug: "tickets", title: "Tickets", icon: Ticket, group: "Ticketing", description: "Ticket types, pricing in GHS and sales.", emptyTitle: "No ticket types", emptyDescription: "Create free or paid tickets (Mobile Money and card) once an event exists." },
  { slug: "check-in", title: "QR Check-in", icon: QrCode, group: "Ticketing", description: "Scan QR tickets at the entrance.", emptyTitle: "Nothing to scan yet", emptyDescription: "Check-in staff will scan attendee QR codes here on event day." },
  { slug: "schedule", title: "Schedule", icon: Clock, group: "Planning", description: "Programme, sessions and speakers.", emptyTitle: "No schedule items", emptyDescription: "Build your event programme with sessions, times (Africa/Accra) and speakers." },
  { slug: "tasks", title: "Tasks", icon: ListChecks, group: "Planning", description: "Assign and track planning tasks.", emptyTitle: "No tasks", emptyDescription: "Break planning into tasks and assign them to team members with due dates." },
  { slug: "budget", title: "Budget", icon: Wallet, group: "Finance", description: "Plan your event budget in GHS.", emptyTitle: "No budget set", emptyDescription: "Set budget lines per category and compare planned against actual spending." },
  { slug: "expenses", title: "Expenses", icon: Receipt, group: "Finance", description: "Record and track event spending.", emptyTitle: "No expenses recorded", emptyDescription: "Log expenses with receipts so finance managers can reconcile them." },
  { slug: "vendors", title: "Vendors", icon: Store, group: "Partners", description: "Caterers, decorators, AV and other suppliers.", emptyTitle: "No vendors", emptyDescription: "Keep vendor contacts, agreements and payment status in one place." },
  { slug: "sponsors", title: "Sponsors", icon: Handshake, group: "Partners", description: "Sponsorship packages and commitments.", emptyTitle: "No sponsors", emptyDescription: "Track sponsor tiers, pledges and deliverables for each event." },
  { slug: "marketing", title: "Marketing", icon: Megaphone, group: "Engagement", description: "Announcements via email, SMS and WhatsApp.", emptyTitle: "No campaigns", emptyDescription: "Send announcements to registrants and share event pages on WhatsApp." },
  { slug: "reports", title: "Reports", icon: BarChart3, group: "Engagement", description: "Attendance, sales and financial reports.", emptyTitle: "No data to report", emptyDescription: "Reports are generated from real registrations, tickets and expenses once events run." },
  { slug: "team", title: "Team", icon: UsersRound, group: "Organisation", description: "Invite collaborators and assign roles.", emptyTitle: "Just you for now", emptyDescription: "Invite event managers, finance managers and check-in staff with specific permissions." },
  { slug: "settings", title: "Settings", icon: Settings, group: "Organisation", description: "Workspace preferences and defaults.", emptyTitle: "Settings coming soon", emptyDescription: "Configure currency (GHS), timezone (Africa/Accra), branding and payout details." },
];

export const votingSections: { title: string; icon: LucideIcon }[] = [
  { title: "Overview", icon: LayoutDashboard },
  { title: "My Elections", icon: Vote },
  { title: "Candidates", icon: UserSquare2 },
  { title: "Voters", icon: BookUser },
  { title: "Ballots", icon: FileCheck2 },
  { title: "Voting Monitor", icon: Activity },
  { title: "Results", icon: Trophy },
  { title: "Audit Reports", icon: ShieldCheck },
  { title: "Election Settings", icon: Settings },
];

export const adminSections: WorkspaceSection[] = [
  { slug: "users", title: "Users", icon: Users, description: "All platform user accounts.", emptyTitle: "No users loaded", emptyDescription: "User accounts will be listed here once authentication is connected." },
  { slug: "organisations", title: "Organisations", icon: Building2, description: "Tenants using the platform.", emptyTitle: "No organisations", emptyDescription: "Every church, school, association and business tenant will appear here." },
  { slug: "events", title: "Events", icon: CalendarDays, description: "Events across all organisations.", emptyTitle: "No events", emptyDescription: "A platform-wide view of events for moderation and support." },
  { slug: "elections", title: "Elections", icon: Vote, description: "Elections across all organisations.", emptyTitle: "No elections", emptyDescription: "Election oversight becomes available with the voting product." },
  { slug: "subscriptions", title: "Subscriptions", icon: CreditCard, description: "Plans and active subscriptions.", emptyTitle: "No subscriptions", emptyDescription: "Subscription plans and billing status will be managed here." },
  { slug: "payments", title: "Payments", icon: Banknote, description: "Transactions, refunds and payouts.", emptyTitle: "No transactions", emptyDescription: "Verified Paystack and Hubtel transactions will be recorded here server-side." },
  { slug: "reports", title: "Reports", icon: BarChart3, description: "Platform-wide analytics.", emptyTitle: "No reports yet", emptyDescription: "Growth, revenue and usage reports are built from live platform data." },
  { slug: "support", title: "Support", icon: LifeBuoy, description: "Customer support tickets.", emptyTitle: "No support tickets", emptyDescription: "Tickets raised by organisations will be triaged here." },
  { slug: "security", title: "Security", icon: Lock, description: "Security events and admin activity.", emptyTitle: "No security events", emptyDescription: "Sign-in anomalies and admin activity logs will be monitored here." },
  { slug: "settings", title: "Platform Settings", icon: Settings, description: "Feature flags and system settings.", emptyTitle: "Settings coming soon", emptyDescription: "Feature flags, notification templates and system settings live here." },
];

export const overviewIcon = LayoutDashboard;
