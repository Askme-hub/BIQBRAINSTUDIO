import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";


export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — BIQ Brain Studios" },
      { name: "description", content: "BIQ Brain Studios builds trusted digital tools for events and elections, starting in Ghana." },
      { property: "og:title", content: "About Us — BIQ Brain Studios" },
      { property: "og:description", content: "BIQ Brain Studios builds trusted digital tools for events and elections, starting in Ghana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <SiteLayout>
      <PageHero eyebrow="About us" title="Trusted tools for the moments organisations care about" description="We are building a platform that helps Ghanaian organisations plan events and conduct elections with clarity and accountability — and that can grow across Africa." />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-10 md:grid-cols-3">
          {[
            { t: "Our mission", d: "Give every organisation, large or small, professional tools to run gatherings and elections." },
            { t: "Ghana first", d: "Cedi pricing, Mobile Money, Ghanaian phone numbers and WhatsApp sharing from day one." },
            { t: "Honest by default", d: "We are clear about what is ready today and what is still being built." },
          ].map((x) => (
            <div key={x.t}><h2 className="text-lg font-semibold">{x.t}</h2><p className="mt-2 text-muted-foreground">{x.d}</p></div>
          ))}
        </div>
        <Link to="/contact" className="mt-12 inline-block text-sm font-medium text-primary">Get in touch →</Link>
      </div>
    </SiteLayout>
  );
}
