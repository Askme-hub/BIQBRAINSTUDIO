import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { EmptyState } from "@/components/common/EmptyState";
import { eventSections } from "@/config/navigation";

export const Route = createFileRoute("/app/events/$section")({
  loader: ({ params }) => {
    const section = eventSections.find((s) => s.slug === params.section);
    if (!section) throw notFound();
    return { slug: section.slug };
  },
  head: ({ loaderData }) => {
    const s = eventSections.find((x) => x.slug === loaderData?.slug);
    const title = `${s?.title ?? "Event workspace"} — BIQ Brain Studios`;
    return {
      meta: [
        { title },
        { name: "description", content: s?.description ?? "Event Management workspace." },
        { property: "og:title", content: title },
        { property: "og:description", content: s?.description ?? "Event Management workspace." },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: SectionPage,
});

function SectionPage() {
  const { slug } = Route.useLoaderData();
  const s = eventSections.find((x) => x.slug === slug)!;
  return (
    <div className="space-y-8">
      <PageHeader title={s.title} description={s.description} />
      <EmptyState icon={s.icon} title={s.emptyTitle} description={s.emptyDescription} />
    </div>
  );
}
