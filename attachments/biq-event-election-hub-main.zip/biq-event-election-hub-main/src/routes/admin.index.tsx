import { createFileRoute } from "@tanstack/react-router";
import { ShieldAlert } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { adminSections } from "@/config/navigation";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Super Admin — BIQ Brain Studios" },
      { name: "description", content: "Platform administration for BIQ Brain Studios." },
      { property: "og:title", content: "Super Admin — BIQ Brain Studios" },
      { property: "og:description", content: "Platform administration for BIQ Brain Studios." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminOverview,
});

function AdminOverview() {
  return (
    <div className="space-y-8">
      <PageHeader title="Platform overview" description="Monitor tenants, revenue and platform health." />
      <div className="flex gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm">
        <ShieldAlert className="size-5 shrink-0 text-destructive" />
        <p>This area will be restricted to platform administrators with multi-factor sign-in, enforced on the server. Access control is set up in a later phase.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {adminSections.slice(0, 8).map((s) => (
          <div key={s.slug} className="rounded-xl border bg-card p-5 shadow-card">
            <div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">{s.title}</p><s.icon className="size-4 text-muted-foreground" /></div>
            <p className="mt-3 font-display text-2xl font-semibold text-muted-foreground/60">—</p>
          </div>
        ))}
      </div>
    </div>
  );
}
