import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
const plans = [
  { n: "Starter", d: "For individuals and small gatherings.", price: "Free", f: ["Free events", "Registrations & attendee list", "QR check-in"], hl: false },
  { n: "Organisation", d: "For churches, schools and associations.", price: "Price to be announced", f: ["Paid ticketing in GHS", "Team roles & tasks", "Budget, vendors & sponsors", "Email & SMS announcements"], hl: true },
  { n: "Enterprise", d: "For large organisations and agencies.", price: "Custom", f: ["Multiple organisations", "Advanced reports", "Priority support", "Elections (when available)"], hl: false },
];

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — BIQ Brain Studios" },
      { name: "description", content: "Simple plans in Ghanaian Cedi for events and elections." },
      { property: "og:title", content: "Pricing — BIQ Brain Studios" },
      { property: "og:description", content: "Simple plans in Ghanaian Cedi for events and elections." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <SiteLayout>
      <PageHero eyebrow="Pricing" title="Plans in Ghanaian Cedi" description="Final pricing is being confirmed. Plans below show what each tier is designed to include." />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {plans.map((p) => (
            <div key={p.n} className={`flex flex-col rounded-2xl border bg-card p-8 ${p.hl ? "border-primary shadow-elevated" : "shadow-card"}`}>
              <h3 className="text-lg font-semibold">{p.n}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{p.d}</p>
              <p className="mt-6 font-display text-3xl font-semibold">{p.price}</p>
              <ul className="mt-6 flex-1 space-y-2.5 text-sm">
                {p.f.map((x) => <li key={x} className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-primary" />{x}</li>)}
              </ul>
              <Button className="mt-8" variant={p.hl ? "default" : "outline"} asChild><Link to="/contact">Talk to us</Link></Button>
            </div>
          ))}
        </div>
        <p className="mt-8 text-center text-xs text-muted-foreground">All prices will be shown in GHS. Payment by Mobile Money or card.</p>
      </div>
    </SiteLayout>
  );
}
