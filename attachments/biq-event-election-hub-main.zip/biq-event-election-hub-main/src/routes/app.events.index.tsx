import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, ClipboardList, Ticket, QrCode, Plus } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { EmptyState } from "@/components/common/EmptyState";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/app/events/")({
  head: () => ({
    meta: [
      { title: "Event overview — BIQ Brain Studios" },
      { name: "description", content: "Overview of your organisation's events." },
      { property: "og:title", content: "Event overview — BIQ Brain Studios" },
      { property: "og:description", content: "Overview of your organisation's events." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Overview,
});

function Overview() {
  const kpis = [
    { l: "Upcoming events", i: CalendarDays },
    { l: "Registrations", i: ClipboardList },
    { l: "Tickets sold (GHS)", i: Ticket },
    { l: "Checked in", i: QrCode },
  ];
  return (
    <div className="space-y-8">
      <PageHeader title="Overview" description="A summary of activity across your events." actions={<Button asChild><Link to="/app/events/$section" params={{ section: "create" }}><Plus /> Create event</Link></Button>} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.l} className="rounded-xl border bg-card p-5 shadow-card">
            <div className="flex items-center justify-between"><p className="text-sm text-muted-foreground">{k.l}</p><k.i className="size-4 text-muted-foreground" /></div>
            <p className="mt-3 font-display text-2xl font-semibold text-muted-foreground/60">—</p>
            <p className="mt-1 text-xs text-muted-foreground">No data yet</p>
          </div>
        ))}
      </div>
      <EmptyState icon={CalendarDays} title="Create your first event" description="Once your organisation is set up, events you create will show live registrations, ticket sales and check-ins here." action={<Button variant="outline" asChild><Link to="/app/events/$section" params={{ section: "my-events" }}>Go to My Events</Link></Button>} />
    </div>
  );
}
