import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AuthLayout, AuthNotice } from "@/components/auth/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Log in — BIQ Brain Studios" },
      { name: "description", content: "Log in to your BIQ Brain Studios account." },
      { property: "og:title", content: "Log in — BIQ Brain Studios" },
      { property: "og:description", content: "Log in to your BIQ Brain Studios account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Login,
});

function Login() {
  return (
    <AuthLayout title="Welcome back" description="Log in to manage your events and elections." footer={<>New to BIQ? <Link to="/register" className="font-medium text-primary">Create an account</Link></>}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); toast.info("Sign-in is being connected in the next phase."); }}>
        <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" autoComplete="email" required /></div>
        <div className="space-y-2">
          <div className="flex items-center justify-between"><Label htmlFor="password">Password</Label><Link to="/forgot-password" className="text-xs font-medium text-primary">Forgot password?</Link></div>
          <Input id="password" type="password" autoComplete="current-password" required />
        </div>
        <Button type="submit" className="w-full">Log in</Button>
      </form>
      <AuthNotice />
    </AuthLayout>
  );
}
