import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";
import { UserSquare2, BookUser, Lock, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
const features = [
  { i: UserSquare2, t: "Candidate management", d: "Positions, candidate profiles and photos." },
  { i: BookUser, t: "Voter rolls", d: "Import eligible voters and issue credentials." },
  { i: Lock, t: "Secret ballots", d: "Choices are stored separately from voter identity." },
  { i: ShieldCheck, t: "Audit logs", d: "Every administrative action is recorded." },
];

export const Route = createFileRoute("/voting")({
  head: () => ({
    meta: [
      { title: "Voting & Elections — BIQ Brain Studios" },
      { name: "description", content: "Online voting for school, church, association and award elections — coming soon to BIQ Brain Studios." },
      { property: "og:title", content: "Voting & Elections — BIQ Brain Studios" },
      { property: "og:description", content: "Online voting for school, church, association and award elections — coming soon to BIQ Brain Studios." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <SiteLayout>
      <PageHero eyebrow="Voting & Elections · Coming soon" title="Elections your members can trust" description="A dedicated workspace for running private organisational elections, public polls and award voting." />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.t} className="rounded-xl border bg-card p-6 shadow-card">
              <div className="grid size-10 place-items-center rounded-lg bg-violet-soft text-violet"><f.i className="size-5" /></div>
              <h3 className="mt-5 font-semibold">{f.t}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 rounded-2xl border bg-card p-8 text-center">
          <h2 className="text-xl font-semibold">Voting launches after Event Management</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-muted-foreground">Create your account now — the same organisation and team will carry over when the voting workspace opens.</p>
          <Button className="mt-6" asChild><Link to="/register">Create an account</Link></Button>
        </div>
      </div>
    </SiteLayout>
  );
}
