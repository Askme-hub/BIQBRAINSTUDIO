import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Building2, CalendarDays, Vote, Plus, Bell, UserRound, CreditCard } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/app/")({
  head: () => ({
    meta: [
      { title: "Your workspaces — BIQ Brain Studios" },
      { name: "description", content: "Choose between Event Management and Voting workspaces." },
      { property: "og:title", content: "Your workspaces — BIQ Brain Studios" },
      { property: "og:description", content: "Choose between Event Management and Voting workspaces." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: WorkspaceSelector,
});

function WorkspaceSelector() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Logo />
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" aria-label="Notifications"><Bell className="size-4" /></Button>
            <Button variant="ghost" size="icon" aria-label="Account"><UserRound className="size-4" /></Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <p className="text-sm text-muted-foreground">Signed-in area</p>
        <h1 className="mt-1 text-3xl font-semibold">Choose a workspace</h1>

        <section className="mt-10 rounded-2xl border bg-card p-6 shadow-card">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="grid size-11 place-items-center rounded-xl bg-secondary text-secondary-foreground"><Building2 className="size-5" /></div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Organisation</p>
                <p className="font-semibold">No organisation yet</p>
                <p className="text-sm text-muted-foreground">Organisations hold your team, events and elections. You can belong to several.</p>
              </div>
            </div>
            <Button variant="outline" disabled><Plus /> Create organisation</Button>
          </div>
        </section>

        <div className="mt-6 grid gap-6 md:grid-cols-2">
          <Link to="/app/events" className="group rounded-2xl border bg-card p-8 shadow-card transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-elevated">
            <div className="flex items-center justify-between">
              <div className="grid size-12 place-items-center rounded-xl bg-primary text-primary-foreground"><CalendarDays className="size-6" /></div>
              <Badge variant="secondary">Available</Badge>
            </div>
            <h2 className="mt-6 text-xl font-semibold">Event Management</h2>
            <p className="mt-2 text-sm text-muted-foreground">Events, registrations, tickets, check-in, planning and finances.</p>
            <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-primary">Open workspace <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" /></span>
          </Link>
          <Link to="/app/voting" className="group rounded-2xl border bg-card p-8 shadow-card transition-all hover:-translate-y-0.5 hover:border-violet hover:shadow-elevated">
            <div className="flex items-center justify-between">
              <div className="grid size-12 place-items-center rounded-xl bg-violet text-primary-foreground"><Vote className="size-6" /></div>
              <Badge className="bg-violet-soft text-violet hover:bg-violet-soft">Coming soon</Badge>
            </div>
            <h2 className="mt-6 text-xl font-semibold">Voting & Elections</h2>
            <p className="mt-2 text-sm text-muted-foreground">Candidates, voter rolls, secret ballots, results and audits.</p>
            <span className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-violet">Preview workspace <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" /></span>
          </Link>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {[{ i: UserRound, t: "Profile & account" }, { i: Bell, t: "Notifications" }, { i: CreditCard, t: "Subscription" }].map((x) => (
            <div key={x.t} className="flex items-center gap-3 rounded-xl border bg-card p-4">
              <x.i className="size-4 text-muted-foreground" />
              <span className="text-sm font-medium">{x.t}</span>
              <span className="ml-auto text-xs text-muted-foreground">Phase 2</span>
            </div>
          ))}
        </div>
        <p className="mt-10 text-xs text-muted-foreground">Platform administrators: <Link to="/admin" className="font-medium text-primary">open Super Admin</Link></p>
      </main>
    </div>
  );
}
