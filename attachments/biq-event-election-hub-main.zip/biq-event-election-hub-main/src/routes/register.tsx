import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AuthLayout, AuthNotice } from "@/components/auth/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/register")({
  head: () => ({
    meta: [
      { title: "Create account — BIQ Brain Studios" },
      { name: "description", content: "Create a BIQ Brain Studios account to run events and elections." },
      { property: "og:title", content: "Create account — BIQ Brain Studios" },
      { property: "og:description", content: "Create a BIQ Brain Studios account to run events and elections." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Register,
});

function Register() {
  return (
    <AuthLayout title="Create your account" description="Start with events today. Voting joins the same account later." footer={<>Already have an account? <Link to="/login" className="font-medium text-primary">Log in</Link></>}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); toast.info("Account creation is being connected in the next phase."); }}>
        <div className="space-y-2"><Label htmlFor="name">Full name</Label><Input id="name" autoComplete="name" required /></div>
        <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" autoComplete="email" required /></div>
        <div className="space-y-2"><Label htmlFor="phone">Phone number</Label><Input id="phone" type="tel" placeholder="024 123 4567" autoComplete="tel" pattern="^(\+233|0)[235][0-9]{8}$" title="Ghanaian number, e.g. 0241234567 or +233241234567" /></div>
        <div className="space-y-2"><Label htmlFor="password">Password</Label><Input id="password" type="password" autoComplete="new-password" minLength={8} required /></div>
        <Button type="submit" className="w-full">Create account</Button>
        <p className="text-xs text-muted-foreground">By creating an account you agree to our terms and privacy policy.</p>
      </form>
      <AuthNotice />
    </AuthLayout>
  );
}
