import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Clock, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — BIQ Brain Studios" },
      { name: "description", content: "Talk to the BIQ Brain Studios team about events, ticketing and elections in Ghana." },
      { property: "og:title", content: "Contact — BIQ Brain Studios" },
      { property: "og:description", content: "Talk to the BIQ Brain Studios team." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <SiteLayout>
      <PageHero eyebrow="Contact" title="Let's talk about your next event" description="Tell us what you're planning — an event, a conference or an election — and we'll get back to you." />
      <div className="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_1.4fr]">
        <ul className="space-y-6">
          {[
            { i: MapPin, t: "Location", d: "Accra, Ghana" },
            { i: Clock, t: "Hours", d: "Mon–Fri, 9:00–17:00 (Africa/Accra)" },
            { i: MessageCircle, t: "WhatsApp & phone", d: "Contact numbers will be published at launch." },
          ].map((x) => (
            <li key={x.t} className="flex gap-4">
              <div className="grid size-10 shrink-0 place-items-center rounded-lg bg-accent text-accent-foreground"><x.i className="size-5" /></div>
              <div><p className="font-medium">{x.t}</p><p className="text-sm text-muted-foreground">{x.d}</p></div>
            </li>
          ))}
        </ul>
        <form
          className="space-y-5 rounded-2xl border bg-card p-6 shadow-card sm:p-8"
          onSubmit={(e) => { e.preventDefault(); toast.info("Message delivery is being connected. Please check back soon."); }}
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-2"><Label htmlFor="name">Full name</Label><Input id="name" required /></div>
            <div className="space-y-2"><Label htmlFor="phone">Phone number</Label><Input id="phone" type="tel" placeholder="024 123 4567" /></div>
          </div>
          <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" required /></div>
          <div className="space-y-2"><Label htmlFor="msg">How can we help?</Label><Textarea id="msg" rows={5} required /></div>
          <Button type="submit" className="w-full sm:w-auto">Send message</Button>
          <p className="text-xs text-muted-foreground">Message delivery is not yet connected; this form will be activated in the next phase.</p>
        </form>
      </div>
    </SiteLayout>
  );
}
