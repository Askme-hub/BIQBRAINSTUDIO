import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { AuthLayout, AuthNotice } from "@/components/auth/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/forgot-password")({
  head: () => ({
    meta: [
      { title: "Reset password — BIQ Brain Studios" },
      { name: "description", content: "Reset the password for your BIQ Brain Studios account." },
      { property: "og:title", content: "Reset password — BIQ Brain Studios" },
      { property: "og:description", content: "Reset the password for your BIQ Brain Studios account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Forgot,
});

function Forgot() {
  return (
    <AuthLayout title="Reset your password" description="Enter your email and we'll send you a reset link." footer={<Link to="/login" className="font-medium text-primary">Back to log in</Link>}>
      <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); toast.info("Password recovery emails are being connected in the next phase."); }}>
        <div className="space-y-2"><Label htmlFor="email">Email</Label><Input id="email" type="email" autoComplete="email" required /></div>
        <Button type="submit" className="w-full">Send reset link</Button>
      </form>
      <AuthNotice />
    </AuthLayout>
  );
}
