import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { WorkspaceShell } from "@/components/workspace/WorkspaceShell";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { eventSections, overviewIcon as OverviewIcon } from "@/config/navigation";

export const Route = createFileRoute("/app/events")({
  component: EventsLayout,
});

function EventsLayout() {
  const groups = [...new Set(eventSections.map((s) => s.group))];
  return (
    <WorkspaceShell
      name="Event Management"
      tag="Events workspace"
      groups={[
        { items: [
          <SidebarMenuButton asChild tooltip="Overview">
            <Link to="/app/events" activeOptions={{ exact: true }} activeProps={{ "data-active": true }}><OverviewIcon /><span>Overview</span></Link>
          </SidebarMenuButton>,
        ] },
        ...groups.map((g) => ({
          label: g,
          items: eventSections.filter((s) => s.group === g).map((s) => (
            <SidebarMenuButton asChild tooltip={s.title}>
              <Link to="/app/events/$section" params={{ section: s.slug }} activeProps={{ "data-active": true }}><s.icon /><span>{s.title}</span></Link>
            </SidebarMenuButton>
          )),
        })),
      ]}
    >
      <Outlet />
    </WorkspaceShell>
  );
}
