import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";
import { CalendarSearch } from "lucide-react";
import { EmptyState } from "@/components/common/EmptyState";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/discover")({
  head: () => ({
    meta: [
      { title: "Discover Events — BIQ Brain Studios" },
      { name: "description", content: "Find conferences, church programmes, school events and more happening across Ghana." },
      { property: "og:title", content: "Discover Events — BIQ Brain Studios" },
      { property: "og:description", content: "Find conferences, church programmes, school events and more happening across Ghana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <SiteLayout>
      <PageHero eyebrow="Discover" title="Events happening across Ghana" description="Browse public events from churches, schools, associations and businesses — and get your tickets in a few taps." />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <EmptyState icon={CalendarSearch} title="No public events published yet" description="When organisations publish events on BIQ Brain Studios, they will be listed here with dates, venues and ticket prices in GHS." action={<Button asChild><Link to="/register">Publish your event</Link></Button>} />
      </div>
    </SiteLayout>
  );
}
