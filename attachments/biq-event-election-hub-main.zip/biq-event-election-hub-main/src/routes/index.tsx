import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight, CalendarDays, Ticket, QrCode, Wallet, Users, Megaphone, Vote, ShieldCheck,
  Lock, BarChart3, Church, GraduationCap, Building2, Landmark, UserRound, Smartphone, MessageCircle,
} from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { SectionHeading } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BIQ Brain Studios — Events & Online Elections in Ghana" },
      { name: "description", content: "Plan events, sell tickets in GHS, check in guests by QR code and run secure online elections — for churches, schools, associations and businesses in Ghana." },
      { property: "og:title", content: "BIQ Brain Studios — Events & Online Elections in Ghana" },
      { property: "og:description", content: "Event management and online voting for organisations across Ghana." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const eventFeatures = [
  { icon: CalendarDays, title: "Event pages", text: "Publish a professional page for every event and share it on WhatsApp." },
  { icon: Ticket, title: "Tickets in GHS", text: "Sell free or paid tickets with Mobile Money and card payments." },
  { icon: QrCode, title: "QR check-in", text: "Scan tickets at the gate from any phone. No extra hardware." },
  { icon: Wallet, title: "Budgets & expenses", text: "Plan your budget and track every cedi spent." },
  { icon: Users, title: "Teams & tasks", text: "Invite your committee, assign tasks and stay on schedule." },
  { icon: Megaphone, title: "Announcements", text: "Reach attendees by email and SMS before and after the day." },
];

const audiences = [
  { icon: UserRound, title: "Individuals", text: "Weddings, birthdays, funerals and private gatherings." },
  { icon: Church, title: "Churches", text: "Conventions, harvests, retreats and leadership elections." },
  { icon: GraduationCap, title: "Schools", text: "Speech days, reunions and SRC elections." },
  { icon: Landmark, title: "Associations", text: "AGMs, member elections and award nights." },
  { icon: Building2, title: "Businesses", text: "Conferences, launches and staff awards." },
];

function Home() {
  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative overflow-hidden bg-navy text-navy-foreground">
        <div className="grid-fade absolute inset-0" />
        <div className="absolute -right-40 -top-20 size-[36rem] rounded-full bg-primary/25 blur-3xl" />
        <div className="relative mx-auto grid max-w-7xl gap-14 px-4 pb-24 pt-20 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:pt-28">
          <div>
            <Badge className="border-navy-foreground/15 bg-navy-foreground/5 text-navy-foreground/80" variant="outline">Made for Ghana · Prices in GHS</Badge>
            <h1 className="mt-6 text-4xl font-semibold leading-[1.08] sm:text-6xl">
              Run events and elections your members can trust.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-navy-foreground/70">
              BIQ Brain Studios brings event planning, ticketing, check-in and online voting together — in two focused workspaces under one account.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button size="lg" asChild><Link to="/register">Create a free account <ArrowRight /></Link></Button>
              <Button size="lg" variant="outline" className="border-navy-foreground/20 bg-transparent text-navy-foreground hover:bg-navy-foreground/10 hover:text-navy-foreground" asChild>
                <Link to="/discover">Discover events</Link>
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-sm text-navy-foreground/60">
              <span className="flex items-center gap-2"><Smartphone className="size-4" />Mobile Money & card</span>
              <span className="flex items-center gap-2"><MessageCircle className="size-4" />WhatsApp sharing</span>
              <span className="flex items-center gap-2"><ShieldCheck className="size-4" />Role-based access</span>
            </div>
          </div>
          <HeroPreview />
        </div>
      </section>

      {/* Two products */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
        <SectionHeading center eyebrow="Two products, one platform" title="Separate workspaces, built for the job" description="Your events team and your electoral committee each get their own dashboard, navigation and permissions." />
        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <ProductCard icon={CalendarDays} tone="primary" label="Available first" title="Event Management" text="From the first planning meeting to the post-event report." points={["Registrations & attendee lists", "Ticket sales & QR check-in", "Schedule, tasks, vendors & sponsors", "Budget and expense tracking"]} to="/discover" cta="Explore events" />
          <ProductCard icon={Vote} tone="violet" label="Coming soon" title="Online Voting & Elections" text="Private elections, public polls and award voting with auditable results." points={["Candidate & voter roll management", "Secret ballots kept apart from voter identity", "Live turnout monitoring", "Results publication & audit reports"]} to="/voting" cta="Learn about voting" />
        </div>
      </section>

      {/* Event features */}
      <section className="border-y bg-card">
        <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
          <SectionHeading eyebrow="Event Management" title="Everything your committee juggles, in one place" />
          <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border bg-border sm:grid-cols-2 lg:grid-cols-3">
            {eventFeatures.map((f) => (
              <div key={f.title} className="bg-card p-7">
                <f.icon className="size-5 text-primary" />
                <h3 className="mt-5 font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Audiences */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
        <SectionHeading eyebrow="Who it's for" title="For every kind of gathering in Ghana" />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {audiences.map((a) => (
            <div key={a.title} className="rounded-xl border bg-card p-6 shadow-card">
              <div className="grid size-10 place-items-center rounded-lg bg-accent text-accent-foreground"><a.icon className="size-5" /></div>
              <h3 className="mt-5 font-semibold">{a.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{a.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Trust */}
      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6">
        <div className="grid gap-10 rounded-3xl bg-navy p-8 text-navy-foreground sm:p-14 lg:grid-cols-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sidebar-primary">Security by design</p>
            <h2 className="mt-3 text-3xl font-semibold">Built so each organisation only sees its own data</h2>
            <p className="mt-4 text-navy-foreground/70">Access rules are enforced on the server, not just hidden in the interface. Payments are verified with providers before a ticket is issued.</p>
          </div>
          <ul className="grid gap-4 sm:grid-cols-2">
            {[
              { icon: Lock, t: "Organisation isolation", d: "Private records stay inside their organisation." },
              { icon: ShieldCheck, t: "Role-based access", d: "Owners, finance, check-in staff and more." },
              { icon: Vote, t: "Ballot secrecy", d: "Voter identity is stored separately from choices." },
              { icon: BarChart3, t: "Audit trails", d: "Sensitive actions are logged for review." },
            ].map((x) => (
              <li key={x.t} className="rounded-xl border border-navy-foreground/10 bg-navy-foreground/5 p-5">
                <x.icon className="size-5 text-sidebar-primary" />
                <p className="mt-3 font-medium">{x.t}</p>
                <p className="mt-1 text-sm text-navy-foreground/60">{x.d}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t bg-card">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-4 py-16 sm:px-6 md:flex-row md:items-center">
          <div>
            <h2 className="text-2xl font-semibold">Planning something soon?</h2>
            <p className="mt-2 text-muted-foreground">Create your account and set up your organisation in minutes.</p>
          </div>
          <div className="flex gap-3">
            <Button size="lg" asChild><Link to="/register">Get started</Link></Button>
            <Button size="lg" variant="outline" asChild><Link to="/pricing">See pricing</Link></Button>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function ProductCard({ icon: Icon, tone, label, title, text, points, to, cta }: { icon: typeof Vote; tone: "primary" | "violet"; label: string; title: string; text: string; points: string[]; to: "/discover" | "/voting"; cta: string }) {
  const iconCls = tone === "primary" ? "bg-primary text-primary-foreground" : "bg-violet text-primary-foreground";
  const badgeCls = tone === "primary" ? "bg-accent text-accent-foreground" : "bg-violet-soft text-violet";
  return (
    <div className="flex flex-col rounded-2xl border bg-card p-8 shadow-card">
      <div className="flex items-center justify-between">
        <div className={`grid size-11 place-items-center rounded-xl ${iconCls}`}><Icon className="size-5" /></div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium ${badgeCls}`}>{label}</span>
      </div>
      <h3 className="mt-6 text-2xl font-semibold">{title}</h3>
      <p className="mt-2 text-muted-foreground">{text}</p>
      <ul className="mt-6 space-y-2.5 text-sm">
        {points.map((p) => <li key={p} className="flex gap-2.5"><span className={`mt-2 size-1.5 shrink-0 rounded-full ${tone === "primary" ? "bg-primary" : "bg-violet"}`} />{p}</li>)}
      </ul>
      <Link to={to} className="mt-8 inline-flex items-center gap-1.5 text-sm font-medium text-primary">{cta} <ArrowRight className="size-4" /></Link>
    </div>
  );
}

function HeroPreview() {
  return (
    <div className="relative hidden lg:block" aria-hidden>
      <div className="rounded-2xl border border-navy-foreground/10 bg-navy-soft/80 p-5 shadow-elevated backdrop-blur">
        <div className="flex items-center justify-between border-b border-navy-foreground/10 pb-4">
          <p className="font-display text-sm font-semibold">Event workspace</p>
          <span className="rounded-full bg-primary/20 px-2.5 py-0.5 text-xs text-navy-foreground/80">Overview</span>
        </div>
        <div className="mt-5 grid grid-cols-3 gap-3">
          {[{ l: "Registrations", i: Users }, { l: "Tickets sold", i: Ticket }, { l: "Checked in", i: QrCode }].map((k) => (
            <div key={k.l} className="rounded-xl bg-navy-foreground/5 p-4">
              <k.i className="size-4 text-sidebar-primary" />
              <p className="mt-3 text-xs text-navy-foreground/60">{k.l}</p>
              <div className="mt-2 h-2 w-12 rounded bg-navy-foreground/15" />
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2.5 rounded-xl bg-navy-foreground/5 p-4">
          {["Schedule", "Tasks", "Budget (GHS)", "Sponsors"].map((r, i) => (
            <div key={r} className="flex items-center justify-between text-xs">
              <span className="text-navy-foreground/70">{r}</span>
              <div className="h-1.5 rounded-full bg-primary/60" style={{ width: `${30 + i * 15}%` }} />
            </div>
          ))}
        </div>
      </div>
      <div className="absolute -bottom-8 -left-8 w-56 rounded-xl border border-navy-foreground/10 bg-navy-soft p-4 shadow-elevated">
        <div className="flex items-center gap-2"><Vote className="size-4 text-violet" /><p className="text-xs font-medium">Voting workspace</p></div>
        <p className="mt-2 text-xs text-navy-foreground/60">Secret ballots · Audit logs</p>
      </div>
    </div>
  );
}
