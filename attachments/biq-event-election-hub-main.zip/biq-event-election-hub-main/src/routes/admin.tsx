import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { WorkspaceShell } from "@/components/workspace/WorkspaceShell";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { adminSections, overviewIcon as OverviewIcon } from "@/config/navigation";

// NOTE: This shell is not yet protected. Phase 7 must gate it server-side with a platform_admins role check.
export const Route = createFileRoute("/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  return (
    <WorkspaceShell
      name="Super Admin"
      tag="Platform administration"
      groups={[
        { items: [
          <SidebarMenuButton asChild tooltip="Overview">
            <Link to="/admin" activeOptions={{ exact: true }} activeProps={{ "data-active": true }}><OverviewIcon /><span>Overview</span></Link>
          </SidebarMenuButton>,
        ] },
        { label: "Platform", items: adminSections.map((s) => (
          <SidebarMenuButton asChild tooltip={s.title}>
            <Link to="/admin/$section" params={{ section: s.slug }} activeProps={{ "data-active": true }}><s.icon /><span>{s.title}</span></Link>
          </SidebarMenuButton>
        )) },
      ]}
    >
      <Outlet />
    </WorkspaceShell>
  );
}
