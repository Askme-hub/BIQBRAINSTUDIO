import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout, PageHero } from "@/components/site/SiteLayout";
import { BookOpen } from "lucide-react";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help Centre — BIQ Brain Studios" },
      { name: "description", content: "Guides and answers for organisers and attendees using BIQ Brain Studios." },
      { property: "og:title", content: "Help Centre — BIQ Brain Studios" },
      { property: "og:description", content: "Guides and answers for organisers and attendees using BIQ Brain Studios." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});

function Page() {
  return (
    <SiteLayout>
      <PageHero eyebrow="Help Centre" title="How can we help?" description="Guides for organisers, attendees and voters are being written alongside the product." />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-3">
          {["Getting started", "Tickets & payments", "Check-in on event day"].map((t) => (
            <div key={t} className="rounded-xl border bg-card p-6"><BookOpen className="size-5 text-primary" /><h3 className="mt-4 font-semibold">{t}</h3><p className="mt-1 text-sm text-muted-foreground">Articles coming soon.</p></div>
          ))}
        </div>
        <p className="mt-10 text-sm text-muted-foreground">Need help now? <Link to="/contact" className="font-medium text-primary">Contact us</Link>.</p>
      </div>
    </SiteLayout>
  );
}
