import { createFileRoute, notFound } from "@tanstack/react-router";
import { PageHeader } from "@/components/common/PageHeader";
import { EmptyState } from "@/components/common/EmptyState";
import { adminSections } from "@/config/navigation";

export const Route = createFileRoute("/admin/$section")({
  loader: ({ params }) => {
    const section = adminSections.find((s) => s.slug === params.section);
    if (!section) throw notFound();
    return { slug: section.slug };
  },
  head: ({ loaderData }) => {
    const s = adminSections.find((x) => x.slug === loaderData?.slug);
    const title = `${s?.title ?? "Super Admin"} — BIQ Brain Studios`;
    return {
      meta: [
        { title },
        { name: "description", content: s?.description ?? "Platform administration." },
        { property: "og:title", content: title },
        { property: "og:description", content: s?.description ?? "Platform administration." },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
        { name: "robots", content: "noindex" },
      ],
    };
  },
  component: SectionPage,
});

function SectionPage() {
  const { slug } = Route.useLoaderData();
  const s = adminSections.find((x) => x.slug === slug)!;
  return (
    <div className="space-y-8">
      <PageHeader title={s.title} description={s.description} />
      <EmptyState icon={s.icon} title={s.emptyTitle} description={s.emptyDescription} />
    </div>
  );
}
