import { createFileRoute, Link } from "@tanstack/react-router";
import { UserSquare2, BookUser, Lock, ShieldCheck, Activity, Trophy } from "lucide-react";
import { WorkspaceShell } from "@/components/workspace/WorkspaceShell";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { votingSections } from "@/config/navigation";

export const Route = createFileRoute("/app/voting")({
  head: () => ({
    meta: [
      { title: "Voting workspace — BIQ Brain Studios" },
      { name: "description", content: "Online voting and election management — coming soon." },
      { property: "og:title", content: "Voting workspace — BIQ Brain Studios" },
      { property: "og:description", content: "Online voting and election management — coming soon." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Voting,
});

const caps = [
  { i: UserSquare2, t: "Candidate management", d: "Define positions and publish candidate profiles." },
  { i: BookUser, t: "Voter rolls", d: "Import eligible voters and issue one-time credentials." },
  { i: Lock, t: "Secret ballots", d: "Ballot choices are stored apart from voter identity." },
  { i: Activity, t: "Live monitoring", d: "Follow turnout in real time without revealing choices." },
  { i: Trophy, t: "Results publication", d: "Counted automatically on the server and published on approval." },
  { i: ShieldCheck, t: "Audit logs", d: "Every administrative action is recorded for review." },
];

function Voting() {
  return (
    <WorkspaceShell
      name="Voting & Elections"
      tag="Coming soon"
      groups={[{ items: votingSections.map((s, i) => (
        <SidebarMenuButton tooltip={s.title} isActive={i === 0} disabled={i !== 0} className="disabled:opacity-60"><s.icon /><span>{s.title}</span></SidebarMenuButton>
      )) }]}
    >
      <div className="relative overflow-hidden rounded-2xl bg-navy p-8 text-navy-foreground sm:p-12">
        <div className="grid-fade absolute inset-0" />
        <div className="absolute -right-20 -top-20 size-80 rounded-full bg-violet/30 blur-3xl" />
        <div className="relative max-w-2xl">
          <span className="rounded-full bg-violet/25 px-3 py-1 text-xs font-medium">Coming soon</span>
          <h1 className="mt-5 text-3xl font-semibold sm:text-4xl">Online voting, built for trust</h1>
          <p className="mt-4 text-navy-foreground/70">Run school, church, association and award elections from a dedicated workspace — separate from your events, with its own roles for election managers and returning officers.</p>
          <Button className="mt-8" variant="secondary" asChild><Link to="/app/events">Continue with Event Management</Link></Button>
        </div>
      </div>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {caps.map((c) => (
          <div key={c.t} className="rounded-xl border bg-card p-6 shadow-card">
            <div className="grid size-10 place-items-center rounded-lg bg-violet-soft text-violet"><c.i className="size-5" /></div>
            <h3 className="mt-4 font-semibold">{c.t}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{c.d}</p>
          </div>
        ))}
      </div>
    </WorkspaceShell>
  );
}
