# BIQ Event & Election Hub

PROJECT NAME: BIQ BRAIN STUDIOS

PROJECT TYPE:
A premium, multi-tenant SaaS platform combining Event Management and Online Voting & Election Management.

BUSINESS LOCATION:
Ghana. Currency: Ghanaian Cedi (GHS). Timezone: Africa/Accra.

BRAND IDENTITY & DESIGN SYSTEM:
- Deep navy as the primary colour (#0B192C / #1E2E48)
- Electric blue as the main accent (#0052FF / #2563EB)
- White and light grey backgrounds
- Subtle violet accents
- Modern typography, professional Lucide iconography, clean spacing, elegant cards
- Responsive across mobile, tablet, and desktop

For this first development session, follow the scope defined in Section 10 of the attached specification:
1. Establish the BIQ BRAIN STUDIOS project structure and modular architecture.
2. Create the global design system and reusable component tokens.
3. Establish routing and application layouts:
   - Public Website (Homepage, Discover Events, Voting info, Pricing, About, Contact)
   - Authenticated User Area & Workspace Selector (switch between Event Management, Voting, and Org context)
   - Event Management Workspace Shell (sidebar navigation: Overview, My Events, Create Event, Registrations, Attendees, Tickets, QR Check-in, Schedule, Tasks, Budget, Expenses, Vendors, Sponsors, Marketing, Reports, Team, Settings) with realistic empty states
   - Voting Workspace Shell (professional Coming Soon interface highlighting future capabilities: candidate management, voter rolls, secret ballots, audit logs)
   - Platform Super Admin Shell (Users, Organisations, Events, Elections, Subscriptions, Payments, Reports, Security, Platform Settings)
4. Create the public homepage showcasing both Event Management and Election services tailored to individuals, churches, schools, associations, and businesses in Ghana.
5. Create the authentication flow pages (Login, Register, Forgot Password).
6. Provide a technical overview report of created routes, components, and next-phase database integration requirements.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/402c0401-fc41-4a9d-bd70-79fc6f335d3a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
